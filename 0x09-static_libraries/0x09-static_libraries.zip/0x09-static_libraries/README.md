C static libraries
